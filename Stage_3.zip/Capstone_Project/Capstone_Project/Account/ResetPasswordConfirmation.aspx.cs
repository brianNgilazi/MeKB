﻿using System.Web.UI;

namespace Capstone_Project.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}